const pemHeader = {
    public: "-----BEGIN PUBLIC KEY-----\n",
    private: "-----BEGIN PRIVATE KEY-----\n",
};
const pemFooter = {
    public: "\n-----END PUBLIC KEY-----",
    private: "\n-----END PRIVATE KEY-----",
};

export function arrayBufferToBase64(buffer: ArrayBuffer): string {
    const bytes = new Uint8Array(buffer);
    let str = "";
    for (let i = 0; i < bytes.byteLength; i++) {
        str += String.fromCharCode(bytes[i]);
    }
    return btoa(str);
}

function formatAsPem(base64: string, type: "public" | "private"): string {
    // quebra em linhas de 64 caracteres
    const lines = base64.match(/.{1,64}/g) || [];
    return pemHeader[type] + lines.join("\n") + pemFooter[type];
}

export async function generateRsaKeyPair(): Promise<{
    publicKeyPem: string;
    privateKey: CryptoKey;
}> {
    // 1) gera o par RSA-OAEP
    const keyPair = await crypto.subtle.generateKey(
        {
            name: "RSA-OAEP",
            modulusLength: 2048,
            publicExponent: new Uint8Array([0x01, 0x00, 0x01]),
            hash: "SHA-256",
        },
        true,                  // exportável
        ["encrypt", "decrypt"]
    );

    // 2) exporta a chave pública para SPKI (DER)
    const spki = await crypto.subtle.exportKey("spki", keyPair.publicKey);
    const pubB64 = arrayBufferToBase64(spki);
    const publicKeyPem = formatAsPem(pubB64, "public");

    // 3) mantenha a chave privada em memória (não a exporte em texto)
    return { publicKeyPem, privateKey: keyPair.privateKey };
}
