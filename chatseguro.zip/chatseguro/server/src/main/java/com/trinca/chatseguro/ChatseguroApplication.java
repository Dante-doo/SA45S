package com.trinca.chatseguro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChatseguroApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChatseguroApplication.class, args);
	}

}
