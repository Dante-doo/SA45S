package com.trinca.chatseguro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChatseguroApplicationTests {

	@Test
	void contextLoads() {
	}

}
